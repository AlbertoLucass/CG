[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=7944441&assignment_repo_type=AssignmentRepo)
# Lab08 - Processamento de Imagens

Nesse Lab alguns exemplos possuem código e outros são deixados como exercício.

- Experimente algumas composições de efeitos pré-programados do *Three.JS*. Para entender melhor o funcionamento da composição de efeitos consulte [1]. 

- Tente aplicar alguns conhecimentos já vistos nos Labs passados: 

  1. No exemplo "Canais de Cores" voce pode mostrar os 4 canais de cores, como na Figura 1.  
  2. Apresente também os resultados dos filtros de composição ao lado da imagem original, como na Figura 2. 
  
![](images/CanaisDeCores.png)

Figura 1 - Canais de Cores vistos separadamente.

![](images/Composer.png)

Figura 2 - Imagem original e filtrada vistas lado a lado.

[1] https://r105.threejsfundamentals.org/threejs/lessons/threejs-post-processing.html
