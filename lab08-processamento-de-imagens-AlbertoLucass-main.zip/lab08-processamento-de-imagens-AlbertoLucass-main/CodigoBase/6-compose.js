// Processando uma imagem usando shaders no Three.js

import * as THREE from 'three';

import { EffectComposer } 	from '../../../../Assets/scripts/three.js/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } 		from '../../../../Assets/scripts/three.js/examples/jsm/postprocessing/RenderPass.js';
import { FilmPass } 		from '../../../../Assets/scripts/three.js/examples/jsm/postprocessing/FilmPass.js';

const 	rendSize 	= new THREE.Vector2();
var 	pixelSize  	= new THREE.Vector2();

var 	controls, 
		scene,
		camera,
		renderer;

function main() {

	renderer = new THREE.WebGLRenderer();

	renderer.setClearColor(new THREE.Color(0.0, 0.0, 0.0));

	rendSize.x = 
	rendSize.y = Math.max(window.innerWidth, window.innerHeight);

	renderer.setSize(rendSize.x, rendSize.y);

	document.body.appendChild(renderer.domElement);

	scene 	= new THREE.Scene();

	camera = new THREE.OrthographicCamera( -0.5, 0.5, 0.5, -0.5, -1.0, 1.0 );

	scene.add( camera );
	
    var	texture = new THREE.TextureLoader().load("../../../../Assets/Images/lena.png", carregaImagem);

	renderer.autoClear = false;
	renderer.clear();
};

// ******************************************************************** //
// **                                                                ** //
// ******************************************************************** //
function carregaImagem(texture) {

	if (!texture.image) {
		console.log("ERROR: loading texture");
		return;
		}

	var vpSize = new THREE.Vector2(texture.image.width, texture.image.height);
	renderer.setSize(vpSize.x, vpSize.y);

	// Plane
	var plane 			= new THREE.Mesh( 	new THREE.PlaneBufferGeometry(1.0, 1.0, 20, 20),
											new THREE.MeshBasicMaterial( { map : texture } ) );
	plane.name 	= "imagem";
	scene.add( plane );	

	const composer = new EffectComposer(renderer);	

	const renderPass = new RenderPass(scene, camera);		
	composer.addPass(renderPass);

	const filmPass = new FilmPass	(	0.75,   // noise intensity
										0.25,  	// scanline intensity
										300,   	// scanline count
										true  	// grayscale
									);
	filmPass.renderToScreen = true;
	composer.addPass(filmPass);	

	composer.render();
};

main();
