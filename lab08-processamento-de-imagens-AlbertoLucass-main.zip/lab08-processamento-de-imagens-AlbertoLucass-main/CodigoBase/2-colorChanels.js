// Carrega uma imagem e mapeia em textura

import * as THREE from 'three';

const 	rendSize 	= new THREE.Vector2();

var 	controls, 
		scene,
		camera,
		renderer;

var 	pixelSize  	= new THREE.Vector2();

// ******************************************************************** //
// **                                                                ** //
// ******************************************************************** //
function main() {

	renderer = new THREE.WebGLRenderer();

	renderer.setClearColor(new THREE.Color(0.0, 0.0, 0.0));

	rendSize.x = 
	rendSize.y = Math.max(window.innerWidth, window.innerHeight);

	renderer.setSize(rendSize.x, rendSize.y);

	document.body.appendChild(renderer.domElement);

	scene 	= new THREE.Scene();

	camera = new THREE.OrthographicCamera( -0.5, 0.5, 0.5, -0.5, -1.0, 1.0 );

    var	texture = new THREE.TextureLoader().load("../../../../Assets/Images/lena.png", carregaImagem);

	renderer.autoClear = false;
}

// ******************************************************************** //
// **                                                                ** //
// ******************************************************************** //
function carregaImagem(texture) {

	if (!texture.image) {
		console.log("ERROR: loading texture");
		return;
		}

	pixelSize.x = 1.0/texture.image.width;
	pixelSize.y = 1.0/texture.image.height;

	var vpSize = new THREE.Vector2(texture.image.width, texture.image.height);
	renderer.setSize(vpSize.x, vpSize.y);

	var matShader = new THREE.ShaderMaterial( 	{ 	uniforms		: 	{	uSampler 		: 	{ 	type: "t", 	value: texture }, 
																			uPixelSize		: 	{ 	type: "v2", value: pixelSize},
																		},
													vertexShader	: document.getElementById( 'colorChanel_VS' ).textContent,
													fragmentShader	: document.getElementById( 'colorChanel_FS' ).textContent
												} );
	
	// Plane
	var plane 			= new THREE.Mesh( 	new THREE.PlaneBufferGeometry(1.0, 1.0, 20, 20), 
											matShader );
	plane.name 	= "imagem";
	scene.add( plane );	

	renderer.clear();
	renderer.render( scene, camera );	
};

// ******************************************************************** //
// ******************************************************************** //
// ******************************************************************** //

main();


