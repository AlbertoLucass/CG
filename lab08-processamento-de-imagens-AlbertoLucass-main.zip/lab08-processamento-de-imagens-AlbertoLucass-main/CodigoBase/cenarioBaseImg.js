// Carrega uma imagem e mapeia em textura

import * as THREE from 'three';

const 	rendSize 	= new THREE.Vector2();

var 	controls, 
		scene,
		camera,
		renderer;

var 	pixelSize  	= new THREE.Vector2();

// ******************************************************************** //
// **                                                                ** //
// ******************************************************************** //
function main() {

	renderer = new THREE.WebGLRenderer();

	renderer.setClearColor(new THREE.Color(0.0, 0.0, 0.0));

	document.body.appendChild(renderer.domElement);

	scene 	= new THREE.Scene();

	camera = new THREE.OrthographicCamera( -0.5, 0.5, 0.5, -0.5, -1.0, 1.0 );

    var	texture = new THREE.TextureLoader().load("../../../../Assets/Images/lena.png", carregaImagem);
}

// ******************************************************************** //
// **                                                                ** //
// ******************************************************************** //
function carregaImagem(texture) {

	if (!texture.image) {
		console.log("ERROR: loading texture");
		return;
		}

	pixelSize.x = 1.0/texture.image.width;
	pixelSize.y = 1.0/texture.image.height;

	var matShader = new THREE.ShaderMaterial( 	{ 	uniforms		: 	{	uSampler 	: 	{ 	type: "t", 	value: texture }, 
																			uPixelSize	: 	{ 	type: "v2", value: pixelSize},
																		},
													vertexShader	: document.getElementById( 'ImageProcessing_VS' ).textContent,
													fragmentShader	: document.getElementById( 'ImageProcessing_FS' ).textContent
												} );
	
	// Plane
	var plane 			= new THREE.Mesh( 	new THREE.PlaneBufferGeometry(1.0, 1.0, 20, 20), 
											matShader );
	plane.name 	= "imagem";
	scene.add( plane );	

	renderer.setSize(texture.image.width, texture.image.height);
	renderer.clear();
	renderer.render(scene, camera);
}

// ******************************************************************** //
// ******************************************************************** //
// ******************************************************************** //

main();
