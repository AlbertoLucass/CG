// Gerando e desenhando um objeto gráfico 3D genérico com o Three.JS

import * as THREE from 'three';

const 	rendSize 	= new THREE.Vector2();

var 	controls, 
		scene,
		camera,
		renderer;

// ******************************************************************** //
// **                                                                ** //
// ******************************************************************** //
function main() {

	renderer = new THREE.WebGLRenderer();

	renderer.setClearColor(new THREE.Color(0.0, 0.0, 0.0));

	rendSize.x = window.innerWidth * 0.8;
	rendSize.y = window.innerHeight * 0.8;

	renderer.setSize(rendSize.x, rendSize.y);

	document.body.appendChild(renderer.domElement);

	window.addEventListener ( 'resize', onWindowResize 	);

	scene 	= new THREE.Scene();

	// camera = new THREE.OrthographicCamera( -130.0, 130.0, 130.0, -130.0, -1.0, 1.0 );

	camera = new THREE.PerspectiveCamera( 70.0, rendSize.x / rendSize.y, 0.01, 1000.0 );
	camera.position.y = 2.0;
	camera.position.z = 13.0;
	camera.updateProjectionMatrix();

    geraTerreno();

    requestAnimationFrame(anime);

}

/// ***************************************************************
/// ***                                                          **
/// ***************************************************************
function anime(time) {

	var obj = scene.getObjectByName("terreno");

	obj.rotateY(0.001);
	obj.updateMatrix();

	renderer.clear();
	renderer.render(scene, camera);

	requestAnimationFrame(anime);		
}

// ******************************************************************** //
// **                                                                ** //
// ******************************************************************** //
function geraTerreno() {

    const positions 	= [];
    const indices		= [];

    for (let x = -100.0 ; x < 100.0 ; x += 200.0 / 80.0)
	    for (let z = -100.0 ; z < 100.0 ; z += 200.0 / 80.0)
	    	positions.push( x,  0.0,  z); 
    
    for (let i = 0 ; i < 79 ; i++)
	    for (let j = 0 ; j < 79 ; j++) {
	    	indices.push( ( i 	 * 80) 	+  j    ); 
	    	indices.push( ( i 	 * 80) 	+ (j+1) ); 
	    	indices.push( ((i+1) * 80) 	+  j    ); 

	    	indices.push( ( i 	 * 80) 	+ (j+1) ); 
	    	indices.push( ((i+1) * 80) 	+ (j+1) ); 
	    	indices.push( ((i+1) * 80) 	+  j    ); 
	    	}
    
    const ptos = new THREE.BufferGeometry(); 

    ptos.setIndex( indices );
    ptos.setAttribute( 'position', new THREE.Float32BufferAttribute( positions, 3 ) );

    const objPtos 	= new THREE.Mesh 	(	ptos, 
    										new THREE.MeshBasicMaterial(	{	color:0xFFFFFF,
    																			wireframe:true
    																		})
										); 
    objPtos.name 	= "terreno";
	scene.add( objPtos );

	var axis = new THREE.AxesHelper(8.0);
    axis.name = "eixos";
	axis.rotateX(-90.0 * Math.PI / 180.0);
	axis.position.y = 0.2;
	axis.updateMatrix();
    objPtos.add(axis);


}

// ******************************************************************** //
// **                                                                ** //
// ******************************************************************** //
function onWindowResize() {

	rendSize.x = window.innerWidth * 0.8;
	rendSize.y = window.innerHeight * 0.8;

	renderer.setSize(rendSize.x, rendSize.y);

	camera.aspect = rendSize.x / rendSize.y;
	camera.updateProjectionMatrix();

	renderer.clear();
	renderer.render(scene, camera);
}

// ******************************************************************** //
// ******************************************************************** //
// ******************************************************************** //

main();
