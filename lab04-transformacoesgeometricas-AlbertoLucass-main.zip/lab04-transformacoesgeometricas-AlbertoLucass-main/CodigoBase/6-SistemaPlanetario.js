// Construindo um sistema planetário.

import * as THREE from 'three';
import { GUI } 		from '../../../../Assets/scripts/three.js/examples/jsm/libs/lil-gui.module.min.js'

const 	rendSize 	= new THREE.Vector2();

var 	gui 		= new GUI();

var 	scene,
		renderer,
		camera,
		controls;

/// ***************************************************************
/// **                                                           **
/// ***************************************************************

function main() {

	renderer = new THREE.WebGLRenderer();

	renderer.setClearColor(new THREE.Color(0.0, 0.0, 0.0));

	rendSize.x = 
	rendSize.y = Math.min(window.innerWidth, window.innerHeight) * 0.8;

	renderer.setSize(rendSize.x, rendSize.y);

	document.body.appendChild(renderer.domElement);

	scene 	= new THREE.Scene();

	camera = new THREE.OrthographicCamera( -12.0, 12.0, 12.0, -12.0, -12.0, 12.0 );
	scene.add( camera );

	initGUI();

	buildScene();
		
	renderer.clear();
	renderer.render(scene, camera);
	requestAnimationFrame(animate);
};

/// ***************************************************************
/// **                                                           **
/// ***************************************************************

function initGUI() {

	controls = 	{	RotLua 		: true,
					RotTerra 	: true,
					RotTerraLua : true,
					};

	gui.add( controls, 'RotLua');
	gui.add( controls, 'RotTerra');
	gui.add( controls, 'RotTerraLua');
	gui.open();
};

/// ***************************************************************
/// **                                                           **
/// ***************************************************************

function buildScene() {

	// Sistema Solar

	// Eixo do Sol
	var sAxis = new THREE.AxesHelper(4.8);

	// Sol
	var sphereGeometry = new THREE.SphereGeometry( 4.0, 20, 20);                 
	var sphereMat = new THREE.MeshBasicMaterial( {color: 0xffff00, wireframe:true} );
	var sol = new THREE.Mesh( sphereGeometry, sphereMat );
	sol.name = "Sol";
	sol.add(sAxis);

	var grpTerraSol = new THREE.Object3D();
	grpTerraSol.name = "TerraLua";
	// grpTerraSol.rotateZ(Math.PI / 2);

	// Eixo da Terra
	var tAxis = new THREE.AxesHelper(1.2);

	// Terra
	sphereGeometry = new THREE.SphereGeometry( 1.0, 10, 10);                 
	sphereMat = new THREE.MeshBasicMaterial( {color: 0x0000ff, wireframe:true} );
	var terra = new THREE.Mesh( sphereGeometry, sphereMat );
	terra.name = "Terra";
	terra.position.copy(new THREE.Vector3(7.0, 0.0, 0.0));
	// terra.rotateZ(Math.PI / 2);
	terra.add(tAxis);

	// Eixo da Lua
	var lAxis = new THREE.AxesHelper(0.6);

	// Lua
	sphereGeometry = new THREE.SphereGeometry( 0.5, 10, 10 );                 
	sphereMat = new THREE.MeshBasicMaterial( {color: 0xaaaaaa, wireframe:true} );
	var lua = new THREE.Mesh( sphereGeometry, sphereMat );
	lua.name = "Lua";
	lua.position.copy(new THREE.Vector3( 2.0, 0.0, 0.0)); 
	lua.add(lAxis);

	terra.add( lua );

	grpTerraSol.add(terra);	

	scene.add( grpTerraSol );	
	scene.add( sol);	
};

/// ***************************************************************
/// **                                                           **
/// ***************************************************************

function animate() {

	let rotTerraLua	= 0.005;	// Rotação da Terra e da Lua ao redor do sol
	let rotTerra 	= 0.09;		// Rotação da Terra ao redor de seu eixo (Y)
	let rotLua 		= 0.01;		// Rotação da Lua ao redor do seu eixo (X)

	var obj;

	if (controls.RotTerraLua) {
		obj = scene.getObjectByName("TerraLua");
		obj.rotateZ(rotTerraLua);
		obj.updateMatrix();
		}

	if (controls.RotTerra) {
		obj = scene.getObjectByName("Terra");
		obj.rotateY(rotTerra);
		obj.updateMatrix();
		}

	if (controls.RotLua) {
		obj = scene.getObjectByName("Lua");
		obj.rotateX(rotLua);
		obj.updateMatrix();
		}

	renderer.render(scene, camera);

	requestAnimationFrame(animate);
}

/// ***************************************************************
/// ***************************************************************
/// ***************************************************************

main();
