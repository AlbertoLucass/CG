// Sombras "fake"

import * as THREE 			from 'three';
import { OrbitControls } 	from '../../../Assets/scripts/three.js/examples/jsm/controls/OrbitControls.js';
import { OBJLoader } 		from '../../../Assets/scripts/three.js/examples/jsm/loaders/OBJLoader.js';

var scene 			= null;
var renderer		= null;
var camera 			= null;
var orbitControls	= null;
var altura 			= 0.0;
var offset			= 0.01;
var clock;


/// ***************************************************************
/// **                                                           **
/// ***************************************************************
function main() {

	clock = new THREE.Clock();

	scene = new THREE.Scene();

	renderer = new THREE.WebGLRenderer();

	renderer.setClearColor(new THREE.Color(0.0, 0.0, 0.0));
	renderer.setSize(window.innerWidth*0.7, window.innerHeight*0.7);

	document.body.appendChild(renderer.domElement);

	const fov     = 65;
	const aspect  = window.innerWidth / window.innerHeight;
	const near    = 0.1;
	const far     = 100;
	camera        = new THREE.PerspectiveCamera(fov, aspect, near, far);
	camera.position.set(0.0, 2.0, 3.0);
	camera.lookAt(0, 0, 0);

	// Controle de Camera Orbital
	orbitControls 				= new OrbitControls(camera, renderer.domElement);
	orbitControls.autoRotate 	= false;
		
	// Eixos de referencia
	var globalAxis = new THREE.AxesHelper(1.0);
	scene.add( globalAxis );

	// Load Mesh
	const loader = new OBJLoader();
	loader.load('../../../Assets/Models/OBJ/bunny.obj', buildScene);		

	// Ground
    const groundSize 	= 40.0;

  	const txtLoader 	= new THREE.TextureLoader();
    const texture 		= txtLoader.load("../../../Assets/Textures/checker.png");
    texture.wrapS 		= THREE.RepeatWrapping;
    texture.wrapT 		= THREE.RepeatWrapping;
    texture.magFilter 	= THREE.NearestFilter;
    const repeats 		= groundSize / 2;
    texture.repeat.set(repeats, repeats);

    const groundMesh 			= new THREE.Mesh 	( 	new THREE.PlaneBufferGeometry(groundSize, groundSize), 
    													new THREE.MeshStandardMaterial( { 	map   		:   texture,
                        		                        								    side  		:   THREE.DoubleSide,
                        		                           									flatShading	: 	false,
 
                                                  										})
    												);
    groundMesh.rotation.x 		= Math.PI * -.5;
    scene.add(groundMesh);

    // Luz Direcional
    const dLight = new THREE.DirectionalLight(0xFFFFFF, 1);
    dLight.position.set(0, 2.0, 0);
    scene.add(dLight);

	const helper = new THREE.DirectionalLightHelper( dLight );
	scene.add( helper );

	renderer.clear();
	render();
}

/// ***************************************************************
/// **                                                           **
/// ***************************************************************
function buildScene(loadedMesh) {

	var material 		= new THREE.MeshPhongMaterial( 	{ 	color 		: 	new THREE.Color(0.0, 0.0, 1.0),
															specular 	: 	new THREE.Color(0.7, 0.7, 0.7), 
															shininess	: 	100,
														} );


	loadedMesh.children.forEach(function (child) {
		child.material 		= material;
		});

	loadedMesh.name = "bunny";

	const box 		= new THREE.Box3().setFromObject(loadedMesh);
	
	const maxCoord 	= Math.max(	(box.max.x - box.min.x),
								(box.max.y - box.min.y),
								(box.max.z - box.min.z) );

	if (maxCoord > 1.0)
		loadedMesh.scale.x = 
		loadedMesh.scale.y = 
		loadedMesh.scale.z = 1.0 / maxCoord;

	const base = new THREE.Object3D();
	base.add(loadedMesh);

  	const txtLoader 	= new THREE.TextureLoader();
	const shadowTexture = txtLoader.load("../../../Assets/Textures/roundshadow.png");

	const shadowMesh = new THREE.Mesh(	new THREE.PlaneGeometry(1.0, 1.0), 
										new THREE.MeshBasicMaterial(	{	map 		: 	shadowTexture,
																			transparent : 	true,    // so we can see the ground
																			depthWrite 	: 	false,    // so we don't have to sort
																		}));
	shadowMesh.position.y = 0.001;  // so we're above the ground slightly
	shadowMesh.rotation.x = Math.PI * -.5;
	const shadowSize = 1.0;
	shadowMesh.scale.set(shadowSize, shadowSize, shadowSize);
	shadowMesh.name = "fakeShadow";
	base.add(shadowMesh);

	scene.add(base);
}

/// ***************************************************************
/// **                                                           **
/// ***************************************************************
function render() {
	var delta = clock.getDelta();
    orbitControls.update(delta);

	var obj = scene.getObjectByName("bunny");

	if (obj) {
		altura += offset;
		obj.translateY(offset);
		var shadow = scene.getObjectByName("fakeShadow");

		shadow.material.opacity = THREE.MathUtils.lerp(1.0, 0.25, altura);

		if (altura > 1.0) 
			offset *= -1.0;
		if (altura < 0.0) 
			offset *= -1.0;
		}

	renderer.render(scene, camera);
	requestAnimationFrame(render);
}

/// ***************************************************************
/// ***************************************************************
/// ***************************************************************
/// ***************************************************************
main();
