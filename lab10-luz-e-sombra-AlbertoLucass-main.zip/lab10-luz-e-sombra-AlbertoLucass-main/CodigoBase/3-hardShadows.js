// Sombras "hard"

import * as THREE 			from 'three';
import { OrbitControls } 	from '../../../Assets/scripts/three.js/examples/jsm/controls/OrbitControls.js';
import { OBJLoader } 		from '../../../Assets/scripts/three.js/examples/jsm/loaders/OBJLoader.js';

const   rendSize    	= new THREE.Vector2();
var scene 			= null;
var renderer		= null;
var camera 			= null;
var orbitControls	= null;
var altura 			= 0.0;
var offset			= 0.01;
var clock 			= new THREE.Clock();


/// ***************************************************************
/// **                                                           **
/// ***************************************************************
function main() {

	scene = new THREE.Scene();

	renderer = new THREE.WebGLRenderer();

	renderer.setClearColor(new THREE.Color(0.0, 0.0, 0.0));
	renderer.setSize(window.innerWidth*0.7, window.innerHeight*0.7);

	document.body.appendChild(renderer.domElement);

	const fov     = 65;
	const aspect  = window.innerWidth / window.innerHeight;
	const near    = 0.1;
	const far     = 100;
	camera        = new THREE.PerspectiveCamera(fov, aspect, near, far);
	camera.position.set(0.0, 2.0, 3.0);
	camera.lookAt(0, 0, 0);

	// Controle de Camera Orbital
	orbitControls 				= new OrbitControls(camera, renderer.domElement);
	orbitControls.autoRotate 	= false;
		
	// Eixos de referencia
	var globalAxis = new THREE.AxesHelper(1.0);
	scene.add( globalAxis );

	// Load Mesh
	const loader = new OBJLoader();
	loader.load('../../../Assets/Models/OBJ/bunny.obj', buildScene);		

	// Ground

    const groundMesh 			= new THREE.Mesh(	new THREE.PlaneGeometry(40.0, 40.0), 
    												new THREE.MeshStandardMaterial( { color: 0x555555 })
    											);
    groundMesh.rotation.x 		= Math.PI * -.5;
	groundMesh.castShadow 		= false;
	groundMesh.receiveShadow 	= true;
    scene.add(groundMesh);

    // Luz Direcional
    const pLight 					= new THREE.PointLight(0xFFFFFF, 1);
    pLight.position.set(0, 10.0, 0);
    scene.add(pLight);

	const helper = new THREE.PointLightHelper( pLight );
	scene.add( helper );

	renderer.clear();
	render();
}

/// ***************************************************************
/// **                                                           **
/// ***************************************************************
function buildScene(loadedMesh) {

	var material 		= new THREE.MeshStandardMaterial( 	{ 	color : new THREE.Color(0.0, 0.0, 1.0),
															} );

	loadedMesh.children.forEach(function (child) {
		child.material	= material;
		});

	loadedMesh.name		= "bunny";
	scene.add(loadedMesh);

	const box 		= new THREE.Box3().setFromObject(loadedMesh);
	
	const maxCoord 	= Math.max(	(box.max.x - box.min.x),
								(box.max.y - box.min.y),
								(box.max.z - box.min.z) );

	if (maxCoord > 1.0)
		loadedMesh.scale.x = 
		loadedMesh.scale.y = 
		loadedMesh.scale.z = 1.0 / maxCoord;

}

/// ***************************************************************
/// **                                                           **
/// ***************************************************************
function render() {
	var delta = clock.getDelta();
    orbitControls.update(delta);

	var obj = scene.getObjectByName("bunny");

	if (obj) {
		altura += offset;
		obj.translateY(offset);

		if (altura > 1.0) 
			offset *= -1.0;
		if (altura < 0.0) 
			offset *= -1.0;
		}

	renderer.render(scene, camera);
	requestAnimationFrame(render);
}

/// ***************************************************************
/// ***************************************************************
/// ***************************************************************
/// ***************************************************************
main();
