// Luz

import * as THREE 			from 'three';
import { OrbitControls } 	from '../../../Assets/scripts/three.js/examples/jsm/controls/OrbitControls.js';
import { OBJLoader } 		from '../../../Assets/scripts/three.js/examples/jsm/loaders/OBJLoader.js';
import { TeapotGeometry } 	from '../../../Assets/scripts/three.js/examples/jsm/geometries/TeapotGeometry.js';
import { GUI } 				from '../../../Assets/scripts/three.js/examples/jsm/libs/lil-gui.module.min.js'

const   rendSize    	= new THREE.Vector2();

var 	scene 			= null;
var 	renderer		= null;
var 	camera 			= null;
var 	orbitControls	= null;
var 	params			= null;
var 	maxCoord;
var 	mat,
		light;

var clock  				= new THREE.Clock();
var gui 				= new GUI();

/// ***************************************************************
/// **                                                           **
/// ***************************************************************

function main() {

    scene = new THREE.Scene();
    renderer = new THREE.WebGLRenderer();
    renderer.setClearColor(0x000000, 1.0);

    rendSize.x = 
    rendSize.y = Math.min(window.innerWidth*0.8, window.innerHeight*0.8);

    renderer.setSize(rendSize.x, rendSize.y);
    document.body.appendChild(renderer.domElement);

	camera = new THREE.PerspectiveCamera(60.0, 1.0, 0.1, 30.0);
	
	orbitControls 	= new OrbitControls(camera, renderer.domElement);

	light = new THREE.AmbientLight( 0xFFFFFF, 1.0 );
	scene.add(light);

	mat = new THREE.MeshBasicMaterial(	{ 	color : 0x708090 } );

	buildScene();
			
	render();
}

/// ***************************************************************
/// **                                                           **
/// ***************************************************************

function render() {
	var delta = clock.getDelta();
    orbitControls.update(delta);

	renderer.render(scene, camera);
	requestAnimationFrame(render);
}

/// ***************************************************************
/// **                                                           **
/// ***************************************************************

function buildScene() {

	const teapot 		= new TeapotGeometry( 15, 18 );
	const mesh 			= new THREE.Mesh( teapot, mat );
	mesh.name 			= "teapot";

	scene.add(mesh);

	var box 			= new THREE.Box3();
	box.setFromObject(mesh);

	// Adjust Camera Position and LookAt	
	maxCoord 			= Math.max(box.max.x,box.max.y,box.max.z);	

	camera.position.x 	= 
	camera.position.y 	= 
	camera.position.z 	= maxCoord;
	camera.far 			= new THREE.Vector3(	maxCoord*5, 
												maxCoord*5, 
												maxCoord*5).length();

	camera.lookAt(new THREE.Vector3(	(box.max.x + box.min.x) / 2.0,
										(box.max.y + box.min.y) / 2.0,
										(box.max.z + box.min.z) / 2.0 ));
	camera.updateProjectionMatrix();

	// Global Axis
	var globalAxis = new THREE.AxesHelper(maxCoord*1.3);
	scene.add( globalAxis );

	// Ground
	var groundMesh = new THREE.Mesh(	new THREE.PlaneBufferGeometry(	maxCoord*200.0, maxCoord*200.0, 50, 50), 
										new THREE.MeshPhongMaterial(	{	color 	: 0x556B2F,
																			side 	: THREE.DoubleSide,
																		} ));

	groundMesh.name 				= "ground";
	groundMesh.rotation.x 			= -Math.PI / 2;
	groundMesh.position.y 			= box.min.y * 1.1;

	scene.add(groundMesh);
}

/// ***************************************************************
/// **                                                           **
/// ***************************************************************

function initLights() {	

}

main();
