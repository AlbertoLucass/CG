[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=7944434&assignment_repo_type=AssignmentRepo)
# Lab07 - Mapeamento de Texturas

Nesse Lab apresentamos alguns aspectos do suporte do Framework Three.JS a técnica de mapemanto de texturas. 

## Exercícios:

Com base nos códigos fonte fornecidos faça o que se pede:

1. Modifique o arquivo do modelo do cubo utilizado no exemplo "Coordenadas de Textura", para que ele possa ser visualizado como nas figuras abaixo. Considere que as faces opostas possuem o mesmo padrão de textura.

![](images/exercicio1.png) 

2. Modifique o código utilizado no exemplo "Coordenadas de Textura" para que os padrões das figuras abaixo sejam gerados. Atenção, pois dessa vez as coordenadas de textura do modelo original não devem ser alteradas!

![](images/exercicio2.png) 

3. No exemplo dos modelos de planetas, o modelo de urano não apresenta seus aneis. Além disso, o planeta urano possui uma rotação e uma orientação de seus aneis peculiar, como mostra a figura abaixo. Faça os ajustes para que esse modelo apareça corretamente. 

![](https://c.tenor.com/auvG_nQ5fuAAAAAC/equator-uranus101.gif) 

4. Modifique o exemplo do atlas de textura para que apresente os demais modelos que possuem esse tipo de textura, localizados no repositório Assets da disciplina. 
