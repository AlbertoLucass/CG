[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=7564784&assignment_repo_type=AssignmentRepo)
# Lab03 : geração de modelos 3D no Three.JS

Nesse Lab veremos como criar modelos geométricos 3D do zero e carregar modelos gerados em modeladores como [Blender](https://www.blender.org/), [SketchUp](https://www.sketchup.com/), entre outros.

Uma ótima fonte de modelos 3D (pagos e gratuitos) é o [SketchFab](https://sketchfab.com/).

Mas se voce deseja acesso a modelos utilizados para testes academicos, o pesquisador [Morgan McGuire](https://www.cs.williams.edu/~morgan/) mantem um [repositório](http://casual-effects.com/data/index.html) com os principais modelos, a maioria em formato OBJ.

Um pouco da história dos 2 principais modelos 3D usados na literatura de CG pode ser encontrado em:

- [Bunny](http://graphics.stanford.edu/data/3Dscanrep/) 
- [Utah Teapot](https://en.wikipedia.org/wiki/Utah_teapot). 
